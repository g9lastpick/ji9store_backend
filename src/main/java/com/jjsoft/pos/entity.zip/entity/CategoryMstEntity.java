package com.jjsoft.pos.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Comment;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;

import lombok.*;

/**
 * 카테고리 마스터 엔티티
 */
@Entity
@Table(name = "category_mst")
@Comment("카테고리 마스터")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoryMstEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CATEGORY_ID")
    @Comment("내부 식별자")
    private Long categoryId;

    @Column(name = "PARENT_ID")
    @Comment("부모 카테고리 ID")
    private Long parentId;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID", insertable = false, updatable = false)
    @Comment("부모 카테고리")
    private CategoryMstEntity parent;  // 자기 참조

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STORE_ID")
    @Comment("매장 정보")
    private StoreMstEntity store;

    @Column(name = "CATEGORY_CD", nullable = false)
    @Comment("카테고리 코드")
    private String categoryCode;

    @Column(name = "CATEGORY_NM", nullable = false)
    @Comment("카테고리명")
    private String categoryName;

    @Column(name = "SORT_ORDER", columnDefinition = "INT DEFAULT 0")
    @Comment("정렬 순서")
    private Integer sortOrder;

    @Column(name = "DESCRIPTION", length = 1000)
    @Comment("비고")
    private String description;

    @Column(name = "USE_YN", length = 1, columnDefinition = "CHAR(1) DEFAULT 'Y'")
    @Comment("사용 여부")
    private String useYn;

    @CreationTimestamp
    @Column(name = "CREATE_DATE", updatable = false)
    @Comment("생성일자")
    private LocalDateTime createDate;

    @Column(name = "CREATE_USER")
    @Comment("생성자")
    private String createUser;

    @UpdateTimestamp
    @Column(name = "UPDATE_DATE")
    @Comment("수정일자")
    private LocalDateTime updateDate;

    @Column(name = "UPDATE_USER")
    @Comment("수정자")
    private String updateUser;

    @OneToMany(mappedBy = "parent")
    private List<CategoryMstEntity> children = new ArrayList<>();  // 자식 카테고리들
}
