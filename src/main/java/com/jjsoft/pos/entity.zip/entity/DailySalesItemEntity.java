package com.jjsoft.pos.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.Comment;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/** 업로드용 엔티티*/
@Entity
@Table(name = "daily_sales_item")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DailySalesItemEntity {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Comment("식별자")
    private Long id;

    @Column(name = "SALES_DATE", nullable = false)
    @Comment("매출 일자")
    private LocalDate salesDate;

    @Column(name = "SALES_NO")
    @Comment("No. (행 번호)")
    private Integer salesNo;

    @Column(name = "STORE_NAME")
    @Comment("점포명")
    private String storeName;

    @Column(name = "CATEGORY_LV1")
    @Comment("대분류")
    private String categoryLv1;

    @Column(name = "CATEGORY_LV2")
    @Comment("중분류")
    private String categoryLv2;

    @Column(name = "CATEGORY_LV3")
    @Comment("소분류")
    private String categoryLv3;

    @Column(name = "POS_NO")
    @Comment("POS 번호")
    private String posNo;

    @Column(name = "MENU_CODE")
    @Comment("메뉴 코드")
    private String menuCode;

    @Column(name = "MENU_NAME")
    @Comment("메뉴명")
    private String menuName;

    @Column(name = "SALES_QTY")
    @Comment("매출 수량")
    private Integer salesQty;

    @Column(name = "SALES_AMT_TOTAL")
    @Comment("총매출")
    private Integer salesAmtTotal;

    @Column(name = "SALES_AMT_NET")
    @Comment("순매출")
    private Integer salesAmtNet;

    @Column(name = "SALES_AMT_VAT_EXCL")
    @Comment("세금 제외 매출")
    private Integer salesAmtVatExcl;

    @Column(name = "TAX_AMT")
    @Comment("세금")
    private Integer taxAmt;

    @Column(name = "DISCOUNT_AMT")
    @Comment("할인")
    private Integer discountAmt;

    @Column(name = "NET_SALES_RATIO")
    @Comment("순매출 비중(%)")
    private Double netSalesRatio;

    @Column(name = "BARCODE")
    @Comment("바코드")
    private String barcode;

    @Column(name = "CODE_88")
    @Comment("88코드")
    private String code88;

    @CreationTimestamp
    @Column(name = "CREATE_DATE", updatable = false)
    private LocalDateTime createDate;

    @Column(name = "CREATE_USER")
    private String createUser;

    @UpdateTimestamp
    @Column(name = "UPDATE_DATE")
    private LocalDateTime updateDate;

    @Column(name = "UPDATE_USER")
    private String updateUser;
}
